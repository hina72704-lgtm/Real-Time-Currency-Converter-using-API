import requests
import json
import os
from datetime import datetime
import time
from typing import Dict, Optional, List, Tuple

class CurrencyConverter:
    """Main currency converter class with API integration"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self.base_url = "https://api.exchangerate-api.com/v4/latest/"
        self.rates_cache = {}
        self.last_fetch_time = 0
        self.cache_duration = 3600  # Cache for 1 hour
        self.history_file = "history.json"
        self.supported_currencies = []
        
        # Common currencies
        self.common_currencies = {
            'USD': 'US Dollar',
            'EUR': 'Euro',
            'GBP': 'British Pound',
            'JPY': 'Japanese Yen',
            'PKR': 'Pakistani Rupee',
            'INR': 'Indian Rupee',
            'CAD': 'Canadian Dollar',
            'AUD': 'Australian Dollar',
            'CNY': 'Chinese Yuan',
            'CHF': 'Swiss Franc'
        }
        
        self.load_history()
        self.load_supported_currencies()
    
    def load_supported_currencies(self):
        """Load list of supported currencies"""
        self.supported_currencies = list(self.common_currencies.keys())
    
    def fetch_exchange_rates(self, base_currency: str = 'USD') -> Optional[Dict]:
        """Fetch live exchange rates from API"""
        current_time = time.time()
        
        # Check cache
        if base_currency in self.rates_cache:
            cache_time = self.rates_cache[base_currency].get('timestamp', 0)
            if current_time - cache_time < self.cache_duration:
                return self.rates_cache[base_currency]['rates']
        
        try:
            url = f"{self.base_url}{base_currency.upper()}"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                rates = data.get('rates', {})
                
                # Cache the results
                self.rates_cache[base_currency] = {
                    'rates': rates,
                    'timestamp': current_time
                }
                
                return rates
            else:
                print(f"❌ API Error: {response.status_code}")
                return None
                
        except requests.ConnectionError:
            print("❌ No internet connection. Using cached rates if available.")
            if base_currency in self.rates_cache:
                return self.rates_cache[base_currency]['rates']
            return None
        except Exception as e:
            print(f"❌ Error fetching rates: {e}")
            return None
    
    def convert_currency(self, amount: float, from_currency: str, to_currency: str) -> Optional[float]:
        """Convert currency using live exchange rates"""
        from_currency = from_currency.upper()
        to_currency = to_currency.upper()
        
        rates = self.fetch_exchange_rates(from_currency)
        
        if rates and to_currency in rates:
            converted_amount = amount * rates[to_currency]
            return round(converted_amount, 2)
        else:
            print(f"❌ Could not convert {from_currency} to {to_currency}")
            return None
    
    def save_conversion(self, from_curr: str, to_curr: str, amount: float, result: float):
        """Save conversion to history"""
        history_entry = {
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'from_currency': from_curr.upper(),
            'to_currency': to_curr.upper(),
            'amount': amount,
            'result': result,
            'rate': result / amount if amount > 0 else 0
        }
        
        self.history.append(history_entry)
        self.save_history_to_file()
    
    def load_history(self):
        """Load conversion history from file"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    self.history = json.load(f)
            except:
                self.history = []
        else:
            self.history = []
    
    def save_history_to_file(self):
        """Save history to JSON file"""
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.history, f, indent=4)
        except Exception as e:
            print(f"❌ Error saving history: {e}")
    
    def view_history(self):
        """Display conversion history"""
        if not self.history:
            print("\n📜 No conversion history found.")
            return
        
        print("\n" + "="*80)
        print("📜 CONVERSION HISTORY")
        print("="*80)
        
        for i, entry in enumerate(self.history[-10:], 1):  # Show last 10
            print(f"{i}. [{entry['timestamp']}]")
            print(f"   {entry['amount']} {entry['from_currency']} → {entry['result']} {entry['to_currency']}")
            print(f"   Rate: 1 {entry['from_currency']} = {entry['rate']} {entry['to_currency']}")
            print("-"*80)
    
    def display_exchange_rates(self, base_currency: str = 'USD'):
        """Display current exchange rates"""
        base_currency = base_currency.upper()
        rates = self.fetch_exchange_rates(base_currency)
        
        if not rates:
            print("❌ Could not fetch exchange rates")
            return
        
        print("\n" + "="*60)
        print(f"💱 LIVE EXCHANGE RATES (Base: {base_currency})")
        print("="*60)
        
        # Display rates for common currencies
        for code, name in self.common_currencies.items():
            if code in rates:
                print(f"{code:5} ({name[:20]:20}): {rates[code]:10.4f}")
        
        print("="*60)
        print(f"📅 Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    def multi_currency_convert(self):
        """Convert one amount to multiple currencies"""
        try:
            amount = float(input("💰 Enter amount: "))
            from_currency = input("💱 From currency (e.g., USD): ").upper()
            
            rates = self.fetch_exchange_rates(from_currency)
            if not rates:
                return
            
            print(f"\n📊 {amount} {from_currency} equals:")
            print("-"*40)
            
            # Convert to multiple currencies
            targets = ['EUR', 'GBP', 'PKR', 'INR', 'JPY', 'CAD']
            for target in targets:
                if target in rates:
                    converted = amount * rates[target]
                    print(f"{target:5}: {converted:10.2f}")
            
            # Save as a special multi-conversion entry
            self.save_conversion(from_currency, "MULTI", amount, 0)
            
        except ValueError:
            print("❌ Invalid amount")
    
    def validate_currency(self, currency: str) -> bool:
        """Validate currency code"""
        currency = currency.upper()
        rates = self.fetch_exchange_rates('USD')
        return rates and currency in rates
    
    def run(self):
        """Main application menu"""
        print("\n" + "="*50)
        print("💱 REAL-TIME CURRENCY CONVERTER")
        print("="*50)
        print("💡 Powered by ExchangeRate-API")
        print("📍 Supports 160+ currencies worldwide")
        
        while True:
            print("\n" + "="*50)
            print("📋 MAIN MENU")
            print("="*50)
            print("1. 🔄 Convert Currency")
            print("2. 📊 View Exchange Rates")
            print("3. 🔀 Multi-Currency Convert")
            print("4. 📜 View History")
            print("5. 💾 Save Data Manually")
            print("6. 🌍 View Supported Currencies")
            print("7. ❌ Exit")
            print("="*50)
            
            choice = input("👉 Enter your choice (1-7): ").strip()
            
            if choice == '1':
                self.convert_single_currency()
            elif choice == '2':
                base = input("Enter base currency (default USD): ").strip() or 'USD'
                self.display_exchange_rates(base)
            elif choice == '3':
                self.multi_currency_convert()
            elif choice == '4':
                self.view_history()
            elif choice == '5':
                self.save_history_to_file()
                print("✅ History saved successfully!")
            elif choice == '6':
                self.display_supported_currencies()
            elif choice == '7':
                print("\n👋 Thank you for using Currency Converter!")
                print("📊 Have a great day!")
                break
            else:
                print("❌ Invalid choice. Please try again.")
    
    def convert_single_currency(self):
        """Handle single currency conversion"""
        print("\n" + "="*50)
        print("🔄 CURRENCY CONVERSION")
        print("="*50)
        
        try:
            # Get amount
            amount = float(input("💰 Enter amount: "))
            
            # Get from currency
            while True:
                from_curr = input("💱 From currency (e.g., USD, EUR, PKR): ").upper()
                if self.validate_currency(from_curr):
                    break
                print("❌ Invalid currency code. Try again.")
            
            # Get to currency
            while True:
                to_curr = input("🎯 To currency (e.g., USD, EUR, PKR): ").upper()
                if self.validate_currency(to_curr):
                    break
                print("❌ Invalid currency code. Try again.")
            
            # Perform conversion
            result = self.convert_currency(amount, from_curr, to_curr)
            
            if result:
                print("\n" + "="*40)
                print("✅ CONVERSION RESULT")
                print("="*40)
                print(f"{amount:,.2f} {from_curr} = {result:,.2f} {to_curr}")
                print("="*40)
                
                # Save to history
                self.save_conversion(from_curr, to_curr, amount, result)
                
                # Show rate
                rate = result / amount
                print(f"💱 Exchange Rate: 1 {from_curr} = {rate:.4f} {to_curr}")
            else:
                print("❌ Conversion failed. Please try again.")
                
        except ValueError:
            print("❌ Please enter a valid number for amount.")
    
    def display_supported_currencies(self):
        """Display all supported currencies"""
        print("\n" + "="*60)
        print("🌍 SUPPORTED CURRENCIES")
        print("="*60)
        
        for code, name in self.common_currencies.items():
            print(f"{code:5} - {name}")
        
        print("\n💡 Many more currencies are supported!")
        print("Popular codes: AUD, CAD, CHF, CNY, SGD, NZD, etc.")

def main():
    """Main entry point"""
    try:
        # Create converter instance
        converter = CurrencyConverter()
        
        # Test connection
        print("🔍 Testing API connection...")
        test_rates = converter.fetch_exchange_rates('USD')
        
        if test_rates:
            print("✅ API connection successful!")
        else:
            print("⚠️ API connection failed. Using cached data if available.")
        
        # Run the application
        converter.run()
        
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

if __name__ == "__main__":
    main()