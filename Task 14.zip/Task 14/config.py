# config.py
# Free API key from ExchangeRate-API (no signup required for basic usage)
# For production, sign up at https://app.exchangerate-api.com/sign-up

API_KEY = "your-api-key-here"  # Get free key from exchangerate-api.com
BASE_URL = "https://v6.exchangerate-api.com/v6/9d401efd4c7844189a45e2ec/latest/USD"

# If you don't want to sign up, use this demo key (limited)
DEMO_KEY = "YOUR_DEMO_KEY"  # Replace with actual key

# Alternative: Use free endpoint without key (rate limited)
FREE_ENDPOINT = "https://api.exchangerate-api.com/v4/latest/"